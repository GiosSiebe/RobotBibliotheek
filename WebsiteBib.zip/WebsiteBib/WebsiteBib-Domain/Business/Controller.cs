﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebsiteBib_Domain.Persistence;

namespace WebsiteBib_Domain.Business
{
    public class Controller
    {
        Persistence.Controller _controller;
        public Controller()
        {
            _controller = new Persistence.Controller();
        }
        public List<Magazine> getMagazines(string connstring)
        {
            return _controller.getMagazine(connstring);
        }
        public int getCertainMagazin(string naam, string uitgeverij, string thema, string connstring)
        {
            return _controller.getCertainMagazine(naam, uitgeverij, thema, connstring);
        }
        public void addMagazine(string connstring, string naam, string uitgeverij, string thema, string beschrijving, DateTime datum, string foto)
        {
            _controller.addMagazine(connstring, naam, uitgeverij, thema, beschrijving, datum, foto);
        }

        public void deleteMagazine(string naam, DateTime datum, string connstring)
        {
            _controller.deleteMagazine(naam, datum, connstring);
        }

        public void addRobot(int magazineFk, string connstring)
        {
            _controller.addRobot(magazineFk, connstring);
        }

        public void changeRobot(int robotid, int magazineFk, string connstring)
        {
            _controller.changeRobot(robotid, magazineFk, connstring);
        }

        public void deleteRobot(int robotid, string connstring)
        {
            _controller.deleteRobot(robotid, connstring);
        }

        public List<Robot> getRobot(string connstring)
        {
            return _controller.getRobot(connstring);
        }

        public int getRobotById(int id, string connstring)
        {
            return _controller.getRobotById(id, connstring);
        }

        public int getRobotByMagazin(int id, string connstring)
        {
            return _controller.getRobotByMagazin(id, connstring);
        }

        public int getMagazineByName(string name, DateTime datum, string connstring)
        {
            return _controller.getMagazineByName(name, datum, connstring);
        }


        public Magazine getCertainMagazine(int id, string connstring)
        {
            return _controller.getCertainMagazine(id, connstring);
        }
    }
}
