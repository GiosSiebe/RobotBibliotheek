﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebsiteBib_Domain.Business
{
    public class Magazine
    {
        //velden
        private int _id;
        private string _naam;
        private string _uitgeverij;
        private string _thema;
        private string _beschrijving;
        private DateTime _datum;
        private string _foto;
        //eigenschappen
        public int ID { get { return _id; } }
        public string Naam { get { return _naam; } }
        public string Uitgeverij { get { return _uitgeverij; } }
        public DateTime Datum { get { return _datum; } }
        public string Beschrijving { get { return _beschrijving; } }
        public string Thema { get { return _thema; } }
        public string Foto { get { return _foto; } }
        //constructor
        public Magazine(int id, string naam, string uitgevrij, string thema, string beschrijving, DateTime datm, string foto)
        {
            _id = id;
            _naam = naam;
            _uitgeverij = uitgevrij;
            _thema = thema;
            _beschrijving = beschrijving;
            _datum = datm;
            _foto = foto;
        }
        //methoden
        public override string ToString()
        {
            return "Magazine id:" + _id + ", naam: " + _naam + ", Uitgavedatum: " + _datum.ToShortDateString();
        }
    }
}
