﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace WebsiteBib_Domain.Business
{
    public class Robot
    {
        //velden
        private int robot_id, magazine_fk;

        //getters and setters
        public int RobotId { get { return robot_id; } }
        public int MagazineFk { get { return magazine_fk; } }

        //constructor
        public Robot(int robotId, int magazineFk)
        {
            robot_id = robotId;
            magazine_fk = magazineFk;
        }

        public override string ToString()
        {
            return "Robot Id: " + robot_id + ", Magazine FK: " + magazine_fk;
        }
    }
}
