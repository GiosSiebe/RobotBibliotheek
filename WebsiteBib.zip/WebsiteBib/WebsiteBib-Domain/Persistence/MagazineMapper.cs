﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebsiteBib_Domain.Business;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System.Security.Claims;
using System.Data;

namespace WebsiteBib_Domain.Persistence
{
    class MagazineMapper
    {
        public bool addMagazine(string connstring, string naam, string uitgeverij, string thema, string beschrijving, DateTime datum, string foto)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "INSERT INTO bibliotheek.magazine(naam, uitgeverij, thema, beschrijving, datum, foto)" +
                " VALUES ('"+naam+"', '"+ uitgeverij +"', '"+ thema +"', '"+beschrijving +"', '"+datum.ToString("yyyy-MM-dd") + "', '"+ foto +"')";
           
            MySqlCommand cmd = new MySqlCommand(command, conn);
            
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                conn.Close();
                return false;
            }
            conn.Close();
            return true;
        }
        public int getMagazine(string naam, string uitgeverij, string thema, string constring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(constring);

            //SQL commando specificieren
            MySqlCommand cmd = new MySqlCommand("SELECT m.magazine_id FROM bibliotheek.magazine m WHERE m.naam = '"+ naam +"' AND m.uitgeverij = '"+ uitgeverij +"' AND m.thema = '"+ thema +"';", conn);

            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                int item = Convert.ToInt32(dataReader[0]);
                conn.Close();
                return item;
            }
            return 0;
        }
        public List<Magazine> getMagazinesFromDB(string constring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(constring);

            //Het SQL-commando definiëren
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bibliotheek.magazine;", conn);

            List<Magazine> magazineList = new List<Magazine>();
            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();


            while (dataReader.Read())
            {
                Magazine item = new Magazine(
                    Convert.ToInt32(dataReader[0]),
                Convert.ToString(dataReader[1]),
                Convert.ToString(dataReader[2]),
                Convert.ToString(dataReader[3]),
                Convert.ToString(dataReader[4]),
                Convert.ToDateTime(dataReader[5]),
                Convert.ToString(dataReader[6])
                );
                magazineList.Add(item);
            }
            conn.Close();
            return magazineList;
        }

        public bool deleteMagazine(string naam, DateTime datum, string connstring)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "SET SQL_SAFE_UPDATES = 0;\r\nDELETE FROM bibliotheek.magazine WHERE magazine.naam = '"+naam+"' AND magazine.datum = '"+ datum.ToString("yyyy-MM-dd") + "' AND magazine.magazine_id IS NOT NULL;";

            MySqlCommand cmd = new MySqlCommand(command, conn);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                conn.Close();
                return false;
            }
            conn.Close();
            return true;
        }

        public int getMagazineByName(string naam, DateTime datum, string connstring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(connstring);

            //SQL commando specificieren
            MySqlCommand cmd = new MySqlCommand("SELECT m.magazine_id FROM bibliotheek.magazine m WHERE m.naam = '"+ naam +"' AND m.datum = '"+datum.ToString("yyyy-MM-dd") + "';", conn);

            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                int item = Convert.ToInt32(dataReader[0]);
                conn.Close();
                return item;
            }
            return 0;
        }

        public Magazine getCertainMagazine(int id, string connstring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(connstring);

            //SQL commando specificieren
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bibliotheek.magazine m WHERE m.magazine_id = "+id +";", conn);

            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                Magazine item = new Magazine(
                    Convert.ToInt32(dataReader[0]),
                Convert.ToString(dataReader[1]),
                Convert.ToString(dataReader[2]),
                Convert.ToString(dataReader[3]),
                Convert.ToString(dataReader[4]),
                Convert.ToDateTime(dataReader[5]),
                Convert.ToString(dataReader[6])
                );
                conn.Close();
                return item;
            }
            return null;
        }
    }
}
