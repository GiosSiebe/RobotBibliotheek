﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebsiteBib_Domain.Business;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System.Data;
using System.Data.Common;

namespace WebsiteBib_Domain.Persistence
{
    class RobotMapper
    {
        public bool addRobot(int magazineFk, string connstring)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "INSERT INTO bibliotheek.robot  (FkMagazine) VALUES ("+ magazineFk+");";

            MySqlCommand cmd = new MySqlCommand(command, conn);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                conn.Close();
                return false;
            }
            conn.Close();
            return true;
        }

        public bool changeRobot(int robotid,  int magazineFk, string connstring)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "UPDATE bibliotheek.robot SET FkMagazine = "+ magazineFk +" WHERE robot.robot_id = "+ robotid +";";

            MySqlCommand cmd = new MySqlCommand(command, conn);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                conn.Close();
                return false;
            }
            conn.Close();
            return true;
        }

        public bool deleteRobot(int robotid, string connstring)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "DELETE FROM bibliotheek.robot WHERE robot.robot_id = "+robotid + ";";

            MySqlCommand cmd = new MySqlCommand(command, conn);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                conn.Close();
                return false;
            }
            conn.Close();
            return true;
        }

        public List<Robot> getRobot(string connstring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(connstring);

            //SQL commando specificieren
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bibliotheek.robot;", conn);

            List<Robot> list = new List<Robot>();

            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                Robot robot = new Robot(
                    Convert.ToInt32(dataReader[0]),
                    Convert.ToInt32(dataReader[1])
                );
                list.Add(robot);
            }
            conn.Close();
            return list;
        }

        public int getRobotById(int id, string connstring)
        {
            MySqlConnection conn = new MySqlConnection(connstring);
            string command = "SELECT FkMagazine FROM bibliotheek.robot WHERE robot.robot_id = " + id +";";

            MySqlCommand cmd = new MySqlCommand(command, conn);


            conn.Open();
            int integer;
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                integer = Convert.ToInt32(dataReader[0]);
            }
            conn.Close();
            return id;
        }

        public int getRobotByMagazine(int magazine, string connstring)
        {
            //de connectie met de databank maken
            MySqlConnection conn = new MySqlConnection(connstring);

            //SQL commando specificieren
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bibliotheek.robot WHERE robot.FkMagazine = " + magazine + ";", conn);

            conn.Open();
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                int item = Convert.ToInt32(dataReader[0]);
                conn.Close();
                return item;
            }
            return 0;
        }
    }
}
