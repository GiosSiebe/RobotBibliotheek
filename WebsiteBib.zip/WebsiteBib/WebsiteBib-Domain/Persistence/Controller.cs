﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WebsiteBib_Domain.Business;

namespace WebsiteBib_Domain.Persistence
{
    class Controller
    {
        private string _connectionstring;
        public Controller()
        {
            _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        }
        public Controller(string connstring)
        {
            _connectionstring = connstring;
        }
        public List<Magazine> getMagazine(string connstring)
        {
            MagazineMapper mapper = new MagazineMapper();
            return mapper.getMagazinesFromDB(connstring);
        }
        public int getCertainMagazine(string naam, string uitgeverij, string thema, string connstring)
        {
            MagazineMapper mapper = new MagazineMapper();
            return mapper.getMagazine(naam, uitgeverij, thema, connstring);
        }
        public void addMagazine(string connstring, string naam, string uitgeverij, string thema, string beschrijving, DateTime datum, string foto)
        {
            MagazineMapper mapper = new MagazineMapper();
            mapper.addMagazine(connstring, naam, uitgeverij, thema, beschrijving, datum, foto);
        }

        public void deleteMagazine(string naam, DateTime datum, string connstring)
        {
            MagazineMapper mapper = new MagazineMapper();
            mapper.deleteMagazine(naam, datum, connstring);
        }

        public void addRobot(int magazineFk, string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            mapper.addRobot(magazineFk, connstring);
        }

        public void changeRobot(int robotid, int magazineFk, string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            mapper.changeRobot(robotid, magazineFk, connstring);
        }

        public void deleteRobot(int robotid, string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            mapper.deleteRobot(robotid, connstring);
        }

        public List<Robot> getRobot(string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            return mapper.getRobot(connstring);
        }
        
        public int getRobotById(int id, string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            return mapper.getRobotById(id, connstring);
        }

        public int getRobotByMagazin(int id, string connstring)
        {
            RobotMapper mapper = new RobotMapper();
            return mapper.getRobotByMagazine(id, connstring);
        }

        public int getMagazineByName(string name, DateTime datum ,string connstring)
        {
            MagazineMapper mapper = new MagazineMapper();
            return mapper.getMagazineByName(name, datum, connstring);
        }

        public Magazine getCertainMagazine(int id, string connstring)
        {
            MagazineMapper mapper = new MagazineMapper();
            return mapper.getCertainMagazine(id, connstring);
        }
    }
}
