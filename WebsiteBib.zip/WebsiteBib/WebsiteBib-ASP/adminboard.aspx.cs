﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebsiteBib_Domain.Business;


namespace WebsiteBib_ASP
{
    public partial class adminboard : System.Web.UI.Page
    {
        private Controller _controller;
        private string _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        private List<Magazine> magazinelijst;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["loggedin"] != "yes")
            {
                Response.Redirect("admin.aspx");
            }
            if (IsPostBack)
            {
                _controller = (Controller)HttpContext.Current.Session["_controller"];
            }
            else
            {
                if (HttpContext.Current.Session["_controller"] == null)
                {
                    _controller = new Controller();
                    HttpContext.Current.Session["_controller"] = _controller;
                }
                else
                {
                    _controller = (Controller)HttpContext.Current.Session["_controller"];
                }
            }
            ListBox1.DataSource = _controller.getMagazines(_connectionstring);
            ListBox1.DataBind(); 
            ListBox2.DataSource = _controller.getRobot(_connectionstring);
            ListBox2.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtRobot.Text == "" || txtUitgeverij.Text == "" || txtThema.Text == "" || txtBeschrijving.Text == "" || txtFotolink.Text == "" || txtDatum.Text == "")
            {
                //send message
                string script = "<script>alert('Vul alstublieft alle velden in!.');</script>";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", script);
                return;
            }

            else if ((txtDatum.Text.Length < 9 & txtDatum2.Text == "" )||( txtDatum2.Text.Length < 9 & txtDatum.Text == ""))
            {
                string script = "<script>alert('Vul het juiste formaat in (dd/mm/yyyy).');</script>";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", script);
                return;
            }

            else
            {
                string naam = txtName.Text;
                string uitgeverij = txtUitgeverij.Text;
                string thema = txtThema.Text;
                string beschrijving = txtBeschrijving.Text;
                DateTime datum = Convert.ToDateTime(txtDatum.Text);
                string foto = txtFotolink.Text;
                int robot = Convert.ToInt32(txtRobot.Text);
                _controller.addMagazine(_connectionstring, naam, uitgeverij, thema, beschrijving, datum, foto);
                int id = _controller.getCertainMagazin(naam, uitgeverij, thema, _connectionstring);
                if (_controller.getRobotById(robot, _connectionstring) == id)
                {
                    _controller.changeRobot(robot, id, _connectionstring);
                }
                else
                {
                    _controller.addRobot(id, _connectionstring);
                }
                ListBox1.DataSource = _controller.getMagazines(_connectionstring);
                ListBox1.DataBind();
                ListBox2.DataSource = _controller.getRobot(_connectionstring);
                ListBox2.DataBind();
                txtName.Text = "";
                txtUitgeverij.Text = "";
                txtThema.Text = "";
                txtBeschrijving.Text = "";
                txtDatum.Text = "";
                txtFotolink.Text = "";
                txtRobot.Text = "";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if(txtName2.Text == "" || txtRobot2.Text == "" || txtDatum2.Text == "")
            {
                string script = "<script>alert('Vul alstublieft alle velden in!.');</script>";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", script);
                return;
            }
            else
            {
                string naam2 = txtName2.Text;
                DateTime datum2 = Convert.ToDateTime(txtDatum2.Text);
                _controller.deleteMagazine(naam2, datum2, _connectionstring);
                int idMagazine = _controller.getMagazineByName(naam2, datum2, _connectionstring);
                int idRobot = _controller.getRobotByMagazin(idMagazine, _connectionstring);
                _controller.deleteRobot(idRobot, _connectionstring);
                ListBox1.DataSource = _controller.getMagazines(_connectionstring);
                ListBox1.DataBind();
                ListBox2.DataSource = _controller.getRobot(_connectionstring);
                ListBox2.DataBind();
                txtName2.Text = "";
                txtDatum2.Text = "";
                txtRobot2.Text = "";
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("robots.aspx");
        }
    }
}