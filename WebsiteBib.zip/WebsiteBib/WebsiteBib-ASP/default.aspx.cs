﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebsiteBib_Domain.Business;

namespace WebsiteBib_ASP
{
    public partial class _default : System.Web.UI.Page
    {
        private Controller _controller;
        private List<Magazine> _magazineList = new List<Magazine>();
        private string _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        public int magazineID1, magazineID2, magazineID3, magazineID4, magazineID5, magazineID6;

        protected void Button3_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID3;
            Response.Redirect("magazine.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID5;
            Response.Redirect("magazine.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID6;
            Response.Redirect("magazine.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID4;
            Response.Redirect("magazine.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID2;
            Response.Redirect("magazine.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["ID"] = magazineID1;
            Response.Redirect("magazine.aspx");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                _controller = (Controller)HttpContext.Current.Session["_controller"];
            }
            else
            {
                if (HttpContext.Current.Session["_controller"] == null)
                {
                    _controller = new Controller();
                    HttpContext.Current.Session["_controller"] = _controller;
                }
                else
                {
                    _controller = (Controller)HttpContext.Current.Session["_controller"];
                }
            }
            _magazineList = _controller.getMagazines(_connectionstring);
            int i = 1;
            foreach (Magazine magazine in _magazineList)
            {
                switch (i)
                {
                    case 1:
                        Image1.ImageUrl = magazine.Foto;
                        magazineID1 = magazine.ID;
                        break;
                    case 2:
                        Image2.ImageUrl = magazine.Foto;
                        magazineID2 = magazine.ID;
                        break;
                    case 3:
                        Image3.ImageUrl = magazine.Foto;
                        magazineID3 = magazine.ID;
                        break;
                    case 4:
                        Image4.ImageUrl = magazine.Foto;
                        magazineID4 = magazine.ID;
                        break;
                    case 5:
                        Image5.ImageUrl = magazine.Foto;
                        magazineID5 = magazine.ID;
                        break;
                    case 6:
                        Image6.ImageUrl = magazine.Foto;
                        magazineID6 = magazine.ID;
                        break;
                }
                i++;
            }
        }
    }
}