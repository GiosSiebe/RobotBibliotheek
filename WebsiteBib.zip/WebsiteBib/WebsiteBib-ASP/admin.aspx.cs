﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebsiteBib_Domain.Business;

namespace WebsiteBib_ASP
{
    public partial class admin : System.Web.UI.Page
    {
        private int counter = 0;
        private Controller _controller;
        private string _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpContext.Current.Session["loggedin"] = "no";
            if (IsPostBack)
            {
                _controller = (Controller)HttpContext.Current.Session["_controller"];
            }
            else
            {
                if (HttpContext.Current.Session["_controller"] == null)
                {
                    _controller = new Controller();
                    HttpContext.Current.Session["_controller"] = _controller;
                }
                else
                {
                    _controller = (Controller)HttpContext.Current.Session["_controller"];
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "admin" & password.Text == "admin")
            {
                HttpContext.Current.Session["loggedin"] = "yes";
                Response.Redirect("adminboard.aspx");
            }
            if(counter == 3)
            {
                Button1.Enabled = true;
            }
            counter++;
        }
    }
}