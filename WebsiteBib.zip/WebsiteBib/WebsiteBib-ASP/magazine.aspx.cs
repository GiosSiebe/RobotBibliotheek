﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebsiteBib_Domain.Business;

namespace WebsiteBib_ASP
{
    public partial class magazine : System.Web.UI.Page
    {
        private Controller _controller;
        private string _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        private int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                _controller = (Controller)HttpContext.Current.Session["_controller"];
            }
            else
            {
                if (HttpContext.Current.Session["_controller"] == null)
                {
                    _controller = new Controller();
                    HttpContext.Current.Session["_controller"] = _controller;
                }
                else
                {
                    _controller = (Controller)HttpContext.Current.Session["_controller"];
                }
            }
            id = Convert.ToInt32(Session["ID"].ToString());
            Magazine magazine = _controller.getCertainMagazine(id, _connectionstring);
            naam.Text = magazine.Naam;
            uitgavedatum.Text = magazine.Datum.ToShortDateString();
            thema.Text = magazine.Thema;
            beschrijving.Text = magazine.Beschrijving;
            Image1.ImageUrl = magazine.Foto;
        }

        protected void buttonBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }

        protected void buttonRobot_Click(object sender, EventArgs e)
        {

        }
    }
}