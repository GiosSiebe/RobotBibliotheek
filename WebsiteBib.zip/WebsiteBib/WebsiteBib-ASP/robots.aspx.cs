﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using WebsiteBib_Domain.Business;

namespace WebsiteBib_ASP
{
    public partial class robots : System.Web.UI.Page
    {
        private Controller _controller;
        private string _connectionstring = "server = localhost; user id = root; password=1234; database=bibliotheek";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["loggedin"] != "yes")
            {
                Response.Redirect("admin.aspx");
            }
            if (IsPostBack)
            {
                _controller = (Controller)HttpContext.Current.Session["_controller"];
            }
            else
            {
                if (HttpContext.Current.Session["_controller"] == null)
                {
                    _controller = new Controller();
                    HttpContext.Current.Session["_controller"] = _controller;
                }
                else
                {
                    _controller = (Controller)HttpContext.Current.Session["_controller"];
                }
            }
            ListBox2.DataSource = _controller.getRobot(_connectionstring);
            ListBox2.DataBind();
            ListBox1.DataSource = _controller.getMagazines(_connectionstring);
            ListBox1.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            _controller.addRobot(Convert.ToInt32(txtMagazine.Text), _connectionstring);
            ListBox2.DataSource = _controller.getRobot(_connectionstring);
            ListBox2.DataBind();
            txtMagazine.Text = "";
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            _controller.deleteRobot(Convert.ToInt32(txtRobot.Text), _connectionstring);
            ListBox2.DataSource = _controller.getRobot(_connectionstring);
            ListBox2.DataBind();
            txtRobot.Text = "";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            _controller.changeRobot(Convert.ToInt32(txtRobot2.Text), Convert.ToInt32(txtMagazine1.Text), _connectionstring);
            ListBox2.DataSource = _controller.getRobot(_connectionstring);
            ListBox2.DataBind();
            txtMagazine1.Text = "";
            txtRobot2.Text = "";
        }
    }
}